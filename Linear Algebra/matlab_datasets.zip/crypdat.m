%data for computer project "Cryptography"
A=[1 1;0 3]
B = [1 17;0 9]
C = [1 1; 0 5]


