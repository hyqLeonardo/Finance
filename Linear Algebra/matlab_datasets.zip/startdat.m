% data for computer project Getting Started with MATLAB
format compact
A=[1 2;3 4;5 -6]
B=[1 -2 3;4 5 -6]
x=[4 3 2]'
X=[1 2 3]
C=[-4 8 -1;5 0 3;6 2 10]
D=[2 -1;1 3;-2 1]
E=[2 -1;.1 3;-2 1]
vec=[3 -5 1]'


