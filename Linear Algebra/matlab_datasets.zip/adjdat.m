%data for computer project "Adjacency Matrix of a Graph"
A = [0 1 0 0 0 0;1 0 1 0 0 1;0 1 0 1 0 0;0 0 1 0 1 1];
A = [A; 0 0 0 1 0 1;0 1 0 1 1 0]



