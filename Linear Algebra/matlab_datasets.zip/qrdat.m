% data for computer project QR factorization
format compact
A = [3 -5 1;1 1 1;-1 5 -2;3 -7 8]
B = A(:,1:2)
C = [1 2 5;-1 1 -4;-1 4 -3;1 -4 7;1 2 1]
D=C'
