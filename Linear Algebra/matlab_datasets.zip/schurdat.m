%data for computer project "Schur Complements"
format compact
A11 = [0 -1;1 3]
A12 = [4 1 -1;-2 0 3]
A21 = [2 0;-1 1]
A22 = [1 2 3;4 5 6]


