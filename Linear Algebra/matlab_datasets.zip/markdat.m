%data for computer project "Markov Chains and Long Range Predictions"
format compact
P = [.5 .25 .25;.25 .5 .25;.25 .25 .5]
P1 = [.7 .2 .6; 0 .2 .4;.3 .6  0]
P2 = [.7 .2 .6; 0 .2  0;.3 .6 .4]
P3 = [0 1 0;1 0 0;0 0 1]


