% data for Exercise Set 8.6                                                                                                                                                                                                                                                                                                         % data for Exercise Set 1.1 (4/E)
  
disp ('No data for exercises in Section 8.6.')
