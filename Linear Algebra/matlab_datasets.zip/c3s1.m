% data for Exercise Set 3.1

ex = input('Exercise number (1-18, 37, 41)? ');

if ex==1
   A = [3 0 4;2 3 2;0 5 -1] 
elseif ex==2
   A = [0 5 1;4 -3 0;2 4 1] 
elseif ex==3
   A = [2 -4 3;3 1 2;1 4 -1] 
elseif ex==4
   A = [1 3 5;2 1 1;3 4 2] 
elseif ex==5
   A = [2 3 -4;4 0 5;5 1 6] 
elseif ex==6
   A = [5 -2 4;0 3 -5;2 -4 7] 
elseif ex==7
   A = [4 3 0;6 5 2;9 7 3] 
elseif ex==8
   A = [8 1 6;4 0 3;3 -2 5] 
elseif ex==9
   A = [6 0 0 5;1 7 2 -5;2 0 0 0;8 3 1 8] 
elseif ex==10
   A = [1 -2 5 2;0 0 3 0;2 -6 -7 5;5 0 4 4] 
elseif ex==11
   A = [3 5 -8 4;0 -2 3 -7;0 0 1 5;0 0 0 2] 
elseif ex==12
   A = [4 0 0 0;7 -1 0 0;2 6 3 0;5 -8 4 -3] 
elseif ex==13
   A = [4 0 -7 3 -5;0 0 2 0 0;7 3 -6 4 -8;5 0 5 2 -3;0 0 9 -1 2] 
elseif ex==14
   A = [6 3 2 4 0;9 0 -4 1 0;8 -5 6 7 1;3 0 0 0 0;4 2 3 2 0] 
elseif ex==15
   A = [3 0 4;2 3 2;0 5 -1] 
elseif ex==16
   A = [0 5 1;4 -3 0;2 4 1] 
elseif ex==17
   A = [2 -4 3;3 1 2;1 4  -1] 
elseif ex==18
   A = [1 3 5;2 1 1;3 4 2] 
elseif ex==37
   A = [3 1;4 2] 
elseif ex==41
   u = [3;0], v = [1;2] 
else
   disp('No data for this exercise in Section 3.1.')
end
