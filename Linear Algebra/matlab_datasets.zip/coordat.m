% data for computer project "Homogeneous Coordinates for Comp Graphics"
format compact
box=[6 7 7 6 6;8 8 9 9 8;1 1 1 1 1]
T1 = [1 0 -6;0 1 -8;0 0 1]
R = [cos(pi/3) -sin(pi/3) 0;sin(pi/3) cos(pi/3) 0; 0 0 1]
T2 = [1 0 6;0 1 8;0 0 1]
tri = [2 2 3 2;2 3 3 2;1 1 1 1]
box2 =[0 1 1 0 0;0 0 1 1 0;1 1 1 1 1]
