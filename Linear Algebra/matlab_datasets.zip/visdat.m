%data for computer project "Visualizing Linear Transf. of Plane"
format compact
A = [1 0;2 1]
B = [2 0;0 2]
C = [1 0;0 -1]
D = [-1 0;0 1]
E = [0 -1;-1 0]
F = [cos(pi/4) -sin(pi/4);sin(pi/4) cos(pi/4)]
G = [1 0; 0 0]
box = [0 1 1 0 0;0 0 1 1 0]
flag1 = [1 1 2 2 1;0 3 3 2 2]




