disp('Use the function ''randomint'' instead of ''randintg''.')


