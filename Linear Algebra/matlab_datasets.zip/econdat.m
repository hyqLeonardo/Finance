%data for computer project "Exchange Economy and Homog. Systems"
B = [.8 -.17 -.25 -.2 -.1;-.25 .8 -.1 -.3 0;-.05 -.2 .9 -.15 -.1];
B = [B;-.1 -.28 -.4 .8 0;-.4 -.15 -.15 -.15 .2] 


