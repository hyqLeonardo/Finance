%data for computer projects on population of spotted owls 
A = [0 0 .33;.18 0 0;0 .71 .94]
x0 = [100;100;100]



