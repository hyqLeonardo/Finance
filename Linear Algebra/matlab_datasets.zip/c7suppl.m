% data for Chapter 7 Supplementary Exercises

ex = input('Exercise number (15, 16)?');
if ex==15
   A = [-3 -3 -6 6 1;-1 -1 -1 1 -2;0 0 -1 1 -1;0 0 -1 1 -1]
   b = [6;-1;-4;6]
elseif ex==16
   A = [4 0 -1 -2 0;-5 0 3 5 0;2 0 -1 -2 0;6 0 -3 -6 0]
   b = [6;-1;-4;6]
else
   disp('No data for this supplementary exercise in Chapter 7.') 
end

