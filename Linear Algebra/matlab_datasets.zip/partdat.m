%data for computer project "Partitioned Matrices"
format compact
A11 = [1 2;2 3]
A12 = [4 1 -1;-2 0 3]
A13 = [-2;1]
A21 = [2 0;-1 1;5 3]
A22 = [1 1 2;1 1 3;1 2 3]
A23 = [1;-1;1]
A31 = [9 -2]
A32 = [-5 3 4]
A33 = [1]
C11 = [-2 1;1 2]
C21 = [5 0;-1 3;4 -2]
C31 = [4 7]


