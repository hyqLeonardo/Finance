%data for computer project "Real and Complex Eigenvalues"
% names of matrices changed January 2002.
format compact
U = [5 2;4 3]
V = [4 3;-3 4]
W = [1 1;1 1]
X = [0 1;-1 0]
Y = [0 0 5;1 0 0;0 5 4]


